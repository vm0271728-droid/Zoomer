#!/bin/sh
set -e
cd "$(dirname "$0")"
cargo horizon-mod build
cp target/horizon-mod/hud_zoom.hmod /sdcard/Download/ && ls -lh /sdcard/Download/hud_zoom.hmod
echo "Готово: положи hud_zoom.hmod в horizon-mods/ игры и перезапусти."
