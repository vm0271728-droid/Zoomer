//! Зум на клавишу V: включает/выключает зум камеры.
//! V переназначается на странице мода (Options → Mods → Зум).
//! Кратность зума выбирается в настройках мода.

use horizon_mod_sdk::{input, render, ui, Mod, Registration};

const FACTORS: [(&str, f32); 3] = [("2x", 2.0), ("3x", 3.0), ("4x", 4.0)];

struct Zoom {
    on: bool,
    factor: usize,
}

impl Zoom {
    fn widgets(&self) -> Vec<ui::Widget> {
        vec![
            ui::Widget::Button(ui::ButtonWidget { id: 101, label: format!("Зум: {}", if self.on { "ON" } else { "OFF" }) }),
            ui::Widget::List(ui::ListWidget {
                id: 100,
                rows: FACTORS.iter().map(|f| format!("Кратность: {}", f.0)).collect(),
                selected: Some(self.factor as u32),
            }),
            ui::Widget::Text(ui::TextWidget { id: 110, text: "V — зум (клавишу можно переназначить на этой странице мода)".into(), color: 0xAAAAAA }),
        ]
    }
}

impl Mod for Zoom {
    fn init() -> Result<(Self, Registration), String> {
        input::register_key("zoom", "Зум", "key.keyboard.v")?;
        Ok((Zoom { on: false, factor: 1 }, Registration::new().on_tick().on_frame()))
    }

    fn tick(&mut self, _t: u64) {
        for ev in input::poll() {
            if let input::Event::KeyDown(name) = ev {
                if name == "zoom" {
                    self.on = !self.on;
                }
            }
        }
    }

    fn frame(&mut self, _s: f32) {
        render::set_zoom(&render::Zoom {
            factor: if self.on { FACTORS[self.factor].1 } else { 1.0 },
            smooth: true,
            turn: if self.on { 0.4 } else { 1.0 },
        });
        if self.on {
            let (sw, sh) = render::gui_size();
            let m = 14.0;
            let c = 0xA0FFFFFFu32;
            let mut v = Vec::with_capacity(6);
            v.push(render::Shape::Fill(render::FillShape { rect: render::Rect { x: m, y: m, w: sw - 2.0 * m, h: 1.5 }, color: c }));
            v.push(render::Shape::Fill(render::FillShape { rect: render::Rect { x: m, y: sh - m - 1.5, w: sw - 2.0 * m, h: 1.5 }, color: c }));
            v.push(render::Shape::Fill(render::FillShape { rect: render::Rect { x: m, y: m, w: 1.5, h: sh - 2.0 * m }, color: c }));
            v.push(render::Shape::Fill(render::FillShape { rect: render::Rect { x: sw - m - 1.5, y: m, w: 1.5, h: sh - 2.0 * m }, color: c }));
            v.push(render::Shape::Text(render::TextShape { text: format!("ЗУМ {}", FACTORS[self.factor].0), at: render::Point { x: m + 4.0, y: m + 4.0 }, color: 0xFFFFAA, centered: false, shadow: true }));
            render::set_hud(&v);
        } else {
            render::set_hud(&[]);
        }
    }

    fn ui_select(&mut self, id: u32, row: u32) {
        match id {
            100 => self.factor = row as usize % FACTORS.len(),
            101 => self.on = !self.on,
            _ => return,
        }
        ui::set_settings(&self.widgets());
    }

    fn ui_settings_opened(&mut self) {
        ui::set_settings(&self.widgets());
    }
}

horizon_mod_sdk::export_mod!(Zoom);
