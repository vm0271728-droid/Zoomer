# Зум (V) для Horizon Android (.hmod)

Зум камеры на клавишу V. Исходники + GitHub Actions (автосборка в .hmod).

## Управление
- V — зум ON/OFF (переназначается на странице мода)
- Настройки мода: кратность 2x/3x/4x, тумблер

## Сборка локально (Termux + proot Ubuntu)
    sh build.sh

## Автосборка на GitHub
Загрузи `zoom-mod.zip` в репозиторий, создай файл `.github/workflows/build.yml`
с содержимым из этого архива (лежит тут же) — дальше каждый push собирает мод,
артефакт `hud_zoom-hmod` появляется во вкладке Actions.
