#!/bin/sh
cd "$(dirname "$0")"
rm -f ../zoom-mod.zip
zip -r ../zoom-mod.zip . -x "target/*" -x "*.zip"
echo "Создан: $(dirname "$0")/../zoom-mod.zip"
